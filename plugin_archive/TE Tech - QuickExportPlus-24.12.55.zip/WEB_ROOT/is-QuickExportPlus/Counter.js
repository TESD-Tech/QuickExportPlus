import { h as hydrating, d as delegate, c as create_custom_element, a as append_styles, p as prop, f as first_child, s as slot, t as template_effect, b as append, e as pop, g as set, i as get, j as template, k as state, l as flush_sync, m as push, n as sibling, o as child, r as reset, q as set_text } from './custom-element.js';

/**
 * @param {HTMLElement} dom
 * @param {string} value
 * @returns {void}
 */
function set_class(dom, value) {
	// @ts-expect-error need to add __className to patched prototype
	var prev_class_name = dom.__className;
	var next_class_name = to_class(value);

	if (hydrating && dom.className === next_class_name) {
		// In case of hydration don't reset the class as it's already correct.
		// @ts-expect-error need to add __className to patched prototype
		dom.__className = next_class_name;
	} else if (
		prev_class_name !== next_class_name ||
		(hydrating && dom.className !== next_class_name)
	) {
		// Removing the attribute when the value is only an empty string causes
		// peformance issues vs simply making the className an empty string. So
		// we should only remove the class if the the value is nullish.
		if (value == null) {
			dom.removeAttribute('class');
		} else {
			dom.className = next_class_name;
		}

		// @ts-expect-error need to add __className to patched prototype
		dom.__className = next_class_name;
	}
}

/**
 * @template V
 * @param {V} value
 * @returns {string | V}
 */
function to_class(value) {
	return value == null ? '' : value;
}

const increment = (_, count) => {
	set(count, get(count) + 1);
};

var root = template(`<button> </button> <!>`, 1);

const $$css = {
	hash: "svelte-10nnoa",
	code: "button.svelte-10nnoa {padding:10px;color:#fff;font-size:17px;border-radius:5px;border:1px solid #ccc;cursor:pointer;}.btn-solid.svelte-10nnoa {background:#20c997;border-color:#4cae4c;}.btn-outline.svelte-10nnoa {color:#20c997;background:transparent;border-color:#20c997;}"
};

function Counter($$anchor, $$props) {
	push($$props, true);
	append_styles($$anchor, $$css);

	/**
	 * @typedef {Object} Props
	 * @property {string} [type] - Component props
	 */
	/** @type {Props} */
	let type = prop($$props, "type", 7, "solid");
	let count = state(0);
	var fragment = root();
	var button = first_child(fragment);

	button.__click = [increment, count];

	var text = child(button);

	reset(button);

	var node = sibling(button, 2);

	slot(node, $$props, "default", {}, null);

	template_effect(() => {
		set_class(button, `${(type() == "solid" ? "btn-solid" : "btn-outline") ?? ""} svelte-10nnoa`);
		set_text(text, `count is ${get(count) ?? ""}`);
	});

	append($$anchor, fragment);

	return pop({
		get type() {
			return type();
		},
		set type($$value = "solid") {
			type($$value);
			flush_sync();
		}
	});
}

delegate(["click"]);
customElements.define("ps-svelte-counter", create_custom_element(Counter, { type: {} }, ["default"], [], true));
